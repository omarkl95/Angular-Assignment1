import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  
  data:any[]=
  [
          {id:1,firstName:"ali" ,lastName:"kamal" , contact:"facebook"}, 
         {id:2,firstName:"ahmed" ,lastName:"sayed" , contact:"twitter"},
         {id:3,firstName:"samy" ,lastName:"ahmed" , contact:"google"},
         {id:4,firstName:"samyss" ,lastName:"ahmedss" , contact:"Youtube"}



]
  constructor() { }

  ngOnInit(): void {
  }

}
